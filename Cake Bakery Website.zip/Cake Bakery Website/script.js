$(document).ready(function(){
    $('.dropdown-submenu .dropdown-toggle').on("click", function(e){
        $(this).next('div').toggle();
        e.stopPropagation();
        e.preventDefault();
    });
});